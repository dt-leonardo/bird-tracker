<?php

require('lib/layout.inc');
session_start();

?>

<!DOCTYPE html>
<html lang="it">
<?= set_head('Bird Tracker | Missione'); ?>
<body>
    <?= render_navbar() ?>
    <div class="container">
        <h2 class="mt-4">Missione</h2>
        <p>
            Lo scopo principale di questo progetto è l'uso pratico del linguaggio di programmazione PhP. 
            L'occasione è stata sfruttata per la realizzazione di un sito che emula in parte i servizi di 
            <a href="https://ebird.org/" target="_blank" rel="noopener noreferrer"><em>eBird</em></a> (Cornell Lab of Ornithology)
            e dell'applicazione <em>Animal Tracker</em>. <br>
            L'aspetto fondamentale sia di questo progetto che dei servizi da cui prende ispirazione è l'inclusione
            della società nella scienza. In particolare l'<em>input</em> richiesto fornisce dati necessari
            al monitoraggio e la conservazione di molte specie animali, in questo caso gli uccelli.
        </p>
    </div>
</body>
</html>
