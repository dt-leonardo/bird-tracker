<?php

require('lib/layout.inc');
require('lib/db.inc');

?>

<!DOCTYPE html>
<html lang="it">
<?= set_head('Bird Tracker | Birds'); ?>
<body>
    <?= render_navbar() ?>
    <?php if(isset($_SESSION['auth'])) {
        $uuid = $_SESSION['uuid'];
        $query = "SELECT * FROM `users` WHERE `uuid`='$uuid'";
        $rs = $conn->query($query);
        if(!$rs) {
            die("Error in query");
        }
        $row = $rs->fetch_assoc();
        $full_name = implode(' ',explode('#', $row['full_name']));
    ?>
        <div class="container d-flex flex-column justify-content-center align-items-center" style="height: 70vh;">
            <h2>Benvenuto <b><?= $full_name ?></b></h2>
            <p>Contribuisci alla ricerca scientifica: </p>
            <div class="py-2">
                <a class="btn btn-secondary btn-lg px-3" href="/about.php">Scopri di più</a>
                <a class="btn btn-primary btn-lg px-3" href="/map.php"> Mappa</a>
            </div>
        </div>
    <?php } else { ?>
        <div class="container d-flex flex-column justify-content-center align-items-center" style="height: 70vh;">
            <h1>Bird Tracker</h1>
            <p>Contribuisci alla ricerca scientifica: </p>
            <div class="py-2">
                <a class="btn btn-secondary btn-lg px-3" href="/about.php">Scopri di più</a>
                <a class="btn btn-primary btn-lg px-3" href="/auth.php">Inizia</a>
            </div>
        </div>
    <?php } ?>
</body>
</html>
