<?php

require('lib/layout.inc');
require('lib/db.inc');
session_start();

if (!isset($_SESSION['auth'])) {
    header('Location: index.php');
}

global $conn;
$query = "
    SELECT o.bird_id, o.observation_date, o.longlat, b.species AS species_id, s.nome AS species
    FROM observations o
    INNER JOIN (
        SELECT bird_id, MAX(observation_date) AS max_date
        FROM observations
        GROUP BY bird_id
    ) mo ON o.bird_id = mo.bird_id AND o.observation_date = mo.max_date
    INNER JOIN birds b ON o.bird_id = b.id_ring
    INNER JOIN species s ON b.species = s.id
    ORDER BY o.observation_date DESC;
";

$result = $conn->query($query);

$observations = [];
if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $longlat = explode('#', $row["longlat"]);
        if (count($longlat) == 2) {
            $obs_date = new DateTime($row["observation_date"]);
            $observations[] = [
                "bird_id" => $row["bird_id"],
                "species" => $row["species"],
                "species_id" => $row["species_id"],
                "observation_date" => $obs_date->format('d/m/Y'),
                "longitude" => $longlat[0],
                "latitude" => $longlat[1]
            ];
        }
    }
} else {
    echo "<script>console.log('No data available');</script>";
}
$conn->close();

// Convert PHP array to JSON
$observations_json = json_encode($observations);

?>

<!DOCTYPE html>
<html lang="it">
<?= set_head('Bird Tracker | Mappa'); ?>
<head>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
</head>
<body>
    <?php render_navbar() ?>
    <style>
        #map {
            height: calc(100vh - 64px);
            z-index: 0;
        }

    </style>
    <div class="container-fluid" id="boh">
        <div class="row" style="">
            <div class="col-9" id="map"></div>
            <div class="col-3 overflow-y-auto" style="height: calc(100vh - 64px);">
                <h2 class="card-title text-center">Avvistamenti</h2>
                <?php 
                    foreach ($observations as $obs) {
                        echo render_bird_list_card($obs['bird_id'],$obs['species'],$obs['species_id'],$obs['observation_date'],$obs['latitude'],$obs['longitude']);
                    }
                ?>
            </div>
        </div>
    </div>
    <script>
    // Inizializzazione della mappa
    var map = L.map("map").setView([45.666279, 12.242070], 11);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
    }).addTo(map);

    // Variabile in cui sono contenuti i marker
    var data = <?php echo $observations_json; ?>;

    if (data.length === 0) {
        console.log('No data available');
    } else {
        data.forEach(function(observation) {
            var latitude = parseFloat(observation.latitude);
            var longitude = parseFloat(observation.longitude);
            var birdId = observation.bird_id;
            var observationDate = observation.observation_date;

            if (!isNaN(latitude) && !isNaN(longitude)) {
                // Add a marker for each observation
                L.marker([latitude, longitude])
                    .bindPopup(`<b>Anello:</b> ${birdId}<br><b>Data:</b> ${observationDate}`)
                    .addTo(map);
            } else {
                console.log("Invalid coordinates: ", observation);
            }
        });
    }

    function recenter_map(lat, long){
        map.setView([lat, long], 14);
    }
    </script>
</body>
</html>
