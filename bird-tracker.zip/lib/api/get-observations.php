<?php
require_once('../db.inc');
global $conn;


$ring = strtoupper($_POST["ring"]);
$query = "
        SELECT o.bird_id, o.observation_date, o.longlat, b.species AS species_id, s.nome AS species
        FROM observations o
        INNER JOIN (
            SELECT bird_id, MAX(observation_date) AS max_date
            FROM observations
            GROUP BY bird_id
        ) mo ON o.bird_id = mo.bird_id AND o.observation_date = mo.max_date
        INNER JOIN birds b ON o.bird_id = b.id_ring
        INNER JOIN species s ON b.species = s.id
        WHERE o.bird_id = '$ring'
        ORDER BY o.observation_date DESC;
    ";

$result = $conn->query($query);

$observations = [];
if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $longlat = explode('#', $row["longlat"]);
        if (count($longlat) == 2) {
            $obs_date = new DateTime($row["observation_date"]);
            $observations[] = [
                "bird_id" => $row["bird_id"],
                "species" => $row["species"],
                "species_id" => $row["species_id"],
                "observation_date" => $obs_date->format('d/m/Y'),
                "longitude" => $longlat[0],
                "latitude" => $longlat[1]
            ];
        }
    }
} else {
    die("No data available");
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($observations);
?>
