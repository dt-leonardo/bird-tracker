<?php
require_once('../db.inc');
global $conn;


$ring = strtoupper($_POST["ring"]);
$query = "SELECT `species`.`id`, `species`.`nome` FROM `birds` 
	        INNER JOIN `species` ON `birds`.`species` = `species`.`id`
            WHERE `birds`.`id_ring` = '$ring';";

$result = $conn->query($query);

$observations = [];
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $id = htmlspecialchars($row['id']);
    $name = htmlspecialchars($row['nome']);
    $data = "<option value='$id'>$name</option>";
} else {
    $data = "";
}

$conn->close();

echo $data
?>
