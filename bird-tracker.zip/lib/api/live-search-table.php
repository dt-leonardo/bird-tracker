<?php

require_once('../db.inc');
global $conn;

$ring = strtoupper($_POST["ring"]);
$query = "SELECT birds.id_ring AS `ring`, species.nome AS `name` FROM birds INNER JOIN species ON birds.species = species.id WHERE birds.id_ring LIKE '$ring%';";
$rs = $conn->query($query);

$table_data = '';
while ($row = $rs->fetch_assoc()) {
    $table_data .= '<tr><td onclick="window.location.href=\'bird.php?ring='.$row['ring'].'\'">' . $row['ring'] . '</td>';
    $table_data .= '<td onclick="window.location.href=\'bird.php?ring='.$row['ring'].'\'">' . $row['name'] . '</td></tr>';
}


echo $table_data;
