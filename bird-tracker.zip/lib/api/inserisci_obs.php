<?php 

require('../db.inc');
global $conn;
session_start();

if (isset($_POST['add_bird'])) {
    if (isset($_POST['species'])) {
        $ring = strtoupper($_POST['ring']);
        $species = $_POST['species'];
        $obs_date = $_POST['obs_date'];
        $latlong = str_replace(" ","#",$_POST['latlong']);
        $uuid = $_SESSION['uuid'];
        $query = "INSERT INTO `birds` (`id_ring`, `species`, `name`) VALUES ('$ring', '$species', NULL)";
        if (!$conn->query($query)) {
            die("Error in bird INSERT");
        }
        $query = "INSERT INTO `observations` (`user_id`, `bird_id`, `observation_date`, `longlat`) 
                    VALUES ($uuid, $ring, $obs_date, $latlong) ";
        if (!$conn->query($query)) {
            die("Error in observation INSERT");
        }
    } else {
        $ring = strtoupper($_POST['ring']);
        $obs_date = $_POST['obs_date'];
        $latlong = implode('#', array_reverse(explode(' ', $_POST['latlong'])));
        $uuid = $_SESSION['uuid'];
        $query = "INSERT INTO `observations`(`obs_id`, `user_id`, `bird_id`, `observation_date`, `longlat`) VALUES (NULL,'$uuid','$ring','$obs_date','$latlong')";
        if ($conn->query($query)) {
            
        } else {
            echo "Error: " . $conn->errno;
        }
    }
    header('Location: ../../bird.php');
} else {
    header('Location: ../../index.php');
}
// $rs = $conn->query($query);