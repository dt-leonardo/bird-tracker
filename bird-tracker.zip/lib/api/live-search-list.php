<?php

require_once('../db.inc');
global $conn;

$ring = strtoupper($_POST["ring"]);
$query = "SELECT birds.id_ring AS `ring`, species.nome AS `name` FROM birds INNER JOIN species ON birds.species = species.id WHERE birds.id_ring LIKE '$ring%';";
$rs = $conn->query($query);

$list_item = '';
while ($row = $rs->fetch_assoc()) {
    $list_item .= '<input type="submit" name="ring" value="'.$row['ring'].'">';
}

echo $list_item;
