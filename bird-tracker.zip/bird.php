<?php

require('lib/layout.inc');
require('lib/db.inc');
session_start();

if (!isset($_SESSION['auth'])) {
    header('Location: index.php');
}

global $conn;

if (isset($_GET['ring'])) {
    $ring = $_GET['ring'];
    $query = "SELECT birds.id_ring AS ring, species.nome AS name FROM birds INNER JOIN species ON birds.species = species.id WHERE birds.id_ring='$ring'";
    $rs = $conn->query($query);
    $row = $rs->fetch_assoc();
    $view = 0;
} else {
    $query = "SELECT birds.id_ring AS ring, species.nome AS name FROM birds INNER JOIN species ON birds.species = species.id;";
    $rs = $conn->query($query) or die("Error in species SELECT operation");
    $table_data = "";
    while ($row = $rs->fetch_assoc()) {
        $table_data .= '<tr><td onclick="window.location.href=\'bird.php?ring='.$row['ring'].'\'">' . $row['ring'] . '</td>';
        $table_data .= '<td onclick="window.location.href=\'bird.php?ring='.$row['ring'].'\'">' . $row['name'] . '</td></tr>';
    }
    $view = 1;
}
?>

<!DOCTYPE html>
<html lang="it">
<?= set_head('Bird Tracker | Esemplari Registrati'); ?>
<head>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script src=" https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js "></script>
</head>
<body>
    <?php render_navbar(); ?>
    <div class="container">
        <style>#map{height:500px;}</style>
    <?php if($view == 0) {
        $query = "
        SELECT o.bird_id, o.observation_date, o.longlat, b.species AS species_id, s.nome AS species, s.order, s.family
        FROM observations o
        INNER JOIN birds b ON o.bird_id = b.id_ring
        INNER JOIN species s ON b.species = s.id
        WHERE o.bird_id = '$ring'
        ORDER BY o.observation_date DESC;

    ";
    
    $result = $conn->query($query);
    
    $observations = [];
    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            $longlat = explode('#', $row["longlat"]);
            if (count($longlat) == 2) {
                $obs_date = new DateTime($row["observation_date"]);
                $observations[] = [
                    "bird_id" => $row["bird_id"],
                    "species" => $row["species"],
                    "order" => $row["order"],
                    "family" => $row["family"],
                    "species_id" => $row["species_id"],
                    "observation_date" => $obs_date->format('d/m/Y'),
                    "longitude" => $longlat[0],
                    "latitude" => $longlat[1]
                ];
            }
        }
    } else {
        echo "<script>console.log('No data available')</script>";
    }

    $observations_json = json_encode($observations);
    ?>
        <h1 class="my-5">Esemplare: <?= $_GET['ring']; ?></h1>
        <div class="row my-6">
            <div class="col-5">
                <ul>
                    <li><b>Ordine: </b><?= $observations[0]['order'] ?></li>
                    <li><b>Famiglia: </b><?= $observations[0]['family'] ?></li>
                    <li><b>Specie: </b><?= $observations[0]['species'] ?></li>
                    <li><b>Ultima osservazione: </b><?= $observations[sizeof($observations)-1]['observation_date'] ?></li>
                </ul>
            </div>
            <!-- TODO : Add new api for ebird -->
            <div class="col-7">
                <div id="map"></div>
            </div>
        </div>

        <script>
        // Inizializzazione della mappa
        var map = L.map("map").setView([45.666279, 12.242070], 11)

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            maxZoom: 19,
        }).addTo(map);

        // Variabile in cui sono contenuti i marker
        var markers = [];
        var data = <?php echo $observations_json; ?>;

        if (data.length === 0) {
            console.log('No data available');
        } else {
            data.forEach(function(observation) {
                var latitude = parseFloat(observation.latitude);
                var longitude = parseFloat(observation.longitude);
                var birdId = observation.bird_id;
                var observationDate = observation.observation_date;

                if (!isNaN(latitude) && !isNaN(longitude)) {
                    // Add a marker for each observation
                    var marker = L.marker([latitude, longitude])
                        .bindPopup(`<b>Anello:</b> ${birdId}<br><b>Data:</b> ${observationDate}`)
                        .addTo(map);
                    markers.push(marker);
                } else {
                    console.log("Invalid coordinates: ", observation);
                }
            })
        }

        // Disegna le linee fra i marker
        for (var i = 0; i < markers.length - 1; i++) {
            var startPoint = markers[i].getLatLng();
            var endPoint = markers[i + 1].getLatLng();
            var line = L.polyline([startPoint, endPoint], {color: 'blue'}).addTo(map);
        }   
        </script>
    <?php } else if(isset($_POST['add_obs'])) { 
        $query = "SELECT `species`.`id`, `species`.`nome` FROM `species`;";
        $rs = $conn->query($query);
        if ($rs->num_rows > 0) {
            $species_list = "<option value=''>Seleziona specie</option>";
            while ($row = $rs->fetch_assoc()) {
                $id = htmlspecialchars($row['id']);
                $name = htmlspecialchars($row['nome']);
                $species_list .= "<option value='$id'>$name</option>";
            }
            $species_list_json = json_encode($species_list);
        } else {
            die("Error in SELECT operation");
        }
        ?>
        <h2 class="mt-5">Inserisci nuovo avvistamento</h2>
            <div class="row">
                <div class="col">
                    <form action="lib/api/inserisci_obs.php" method="post">
                        <label for="ring" class="form-label">Anello: </label>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1">#</span>
                            <input type="text" name="ring" id="ring" class="form-control" placeholder="E.g.: N5868">
                        </div>
                        <label for="species" class="form-label">Specie: </label>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="bi bi-feather"></i></span>
                            <select name="species" id="species" class="form-select">
                                <?= $species_list ?>
                            </select>
                        </div>
                        <label for="obs_date" class="form-label">Data dell'avvistamento: </label>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="bi bi-calendar-date"></i></span>
                            <input type="date" name="obs_date" id="obs_date" class="form-control">
                        </div>
                        <label for="longlat" class="form-label">Latitudine e Longitudine: </label>
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><i class="bi bi-geo-alt-fill"></i></span>
                            <input type="text" name="latlong" id="latlong" class="form-control" readonly required>
                        </div>
                        <div class="input-group justify-content-center">
                            <input class="btn btn-primary mt-2 px-4" type="submit" value="Invia" name="add_bird">
                        </div>
                    </form>
                </div>
                <div class="col">
                    <div id="map"></div>
                </div>
            </div>
        <script>
        // Inizializzazione della mappa
        var map = L.map("map").setView([45.666279, 12.242070], 11)

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            maxZoom: 19,
        }).addTo(map);

        var marker;

        // Event listener per aggiungere marker
        map.on("click", function (e) {
            var latlng = e.latlng;
            document.getElementById("latlong").value = `${latlng.lat.toFixed(6)} ${latlng.lng.toFixed(6)}`;
            document.getElementById("latlong").setAttribute("value",`${latlng.lng.toFixed(6)}#${latlng.lat.toFixed(6)}`);

            if (marker) {
            marker.setLatLng(latlng);
            } else {
            marker = L.marker(latlng).addTo(map);
            }
        });

        $(document).ready(function() {
            $('#ring').on('input', function() {
                var ringValue = $(this).val();
                $.ajax({
                    type: 'POST',
                    url: 'lib/api/check_ring.php',
                    data: { ring: ringValue },
                    success: function(response) {
                        if(response) {
                            $('#species').html(response).prop('disabled', true);
                        } else {
                            $('#species').html(<?= $species_list_json ?>).prop('disabled', false);
                        }
                    }
                });
            });
        });
        </script>
    <?php } else { ?>
    <h2 class="my-2">Esemplari registrati</h2>
    <form method="post" class="d-flex flex-row my-5 justify-content-around">
        <div class="input-group" style="width: 35vw">
            <input class="form-control" type="text" id="live-search" autocomplete="off"
            placeholder="Cerca un anello (e.g.N5868)">
            <button class="btn btn-secondary" type="submit"><i class="bi bi-search"></i></button>
        </div>
        <button type="submit" name="add_obs" class="btn btn-secondary"><i class="bi bi-plus"></i>Aggiungi nuovo avvistamento</button>
    </form>
    <table class="table table-hover">
        <thead>
            <th>Anello</th>
            <th>Specie</th>
        </thead>
        <tbody id="table-data">
            <?= $table_data ?>
        </tbody>
    </table>
    <script>
        $(document).ready(function() {
            $('#live-search').on("keyup",function() {
                var search = $(this).val();
                
                $.ajax({
                    method: 'POST',
                    url: 'lib/api/live-search-table.php',
                    data: { ring: search },
                    success:function(response) {
                        $("#table-data").html(response);
                    }
                })
            })
        })
        </script>
    <?php } ?>
    </div>
</body>
</html>
