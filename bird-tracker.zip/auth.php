<?php

require('lib/layout.inc');
require('lib/db.inc');
session_start();

if (isset($_SESSION['auth'])) {
    header('Location: index.php');
}

global $conn;
?>

<!DOCTYPE html>
<html lang='it'>
<?= set_head('Bird Tracker | Autenticazione'); ?>
<body>
  <?php render_navbar() ?>
  <main>
    <?php
    if (isset($_POST['login'])) {
        $uuid = $conn->real_escape_string($_POST['uuid']);
        $query = "SELECT * FROM users WHERE uuid='$uuid' OR email='$uuid'";
        $rs = $conn->query($query) or die("Error in login SELECT operation");
        $row = $rs->fetch_assoc();
        if (is_array($row) && !empty($row)) {
            if (password_verify($_POST['password'], $row['pass_hash'])) {
                $_SESSION['auth'] = true;
                $_SESSION['uuid'] = $row['uuid'];
            } else {
                echo "<div class='errore'><p>Username/Email or Password are incorrect! Try again.</p></div><br>";
                echo "<a href='javascript:self.history.back()'><button class='btn'>Go back</button></a>";
            }
        } else {
            die("Errore nella query");
        }
        if (isset($_SESSION['auth'])) {
            header('Location: index.php');
        }
    } elseif (isset($_POST['registration'])) { ?>
      <div class="container d-flex flex-column justify-content-center align-items-center" style="height: 70vh;">
        <form action="" method="post">
          <div>
            <label for="uuid" class="form-label">Nome Utente:</label>
            <input type="text" name="uuid" class="form-control" id="uuid" required>
          </div>
          <div>
            <label for="email" class="form-label">Email:</label>
            <input type="email" name="email" class="form-control" id="email" required>
          </div>
          <div>
            <label for="name" class="form-label">Nome:</label>
            <input type="text" name="name" class="form-control" id="name" required>
          </div>
          <div>
            <label for="surname" class="form-label">Cognome:</label>
            <input type="text" name="surname" class="form-control" id="surname" required>
          </div>
          <div>
              <label for="password" class="form-label">Password:</label>
            <input type="text" name="password" class="form-control" id="password" required>
          </div>
          <div class="mt-4 d-flex justify-content-center">
            <input type="submit" name="registration-submit" class="btn btn-primary" value="Registration Submit">
          </div>
        </form>
      </div>      
    <?php } elseif (isset($_POST['registration-submit'])) {
        $uuid = $conn->real_escape_string($_POST['uuid']);
        $email = $_POST['email'];
        $full_name = $conn->real_escape_string($_POST['name']) . "#" . $conn->real_escape_string($_POST['surname']);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $query = "INSERT INTO `users`(`uuid`, `full_name`, `email`, `pass_hash`) VALUES ('$uuid','$full_name','$email','$password')";
        $rs = $conn->query($query);
        if ($rs) {
            header("Location: index.php");
        } else {
            echo "<a href='javascript:self.history.back()'><button class='btn'>Go back</button></a>";
        }
        header('Location: index.php');
    } else {
        ?>
      <div class="container d-flex flex-column justify-content-center align-items-center" style="height: 70vh;">
        <h2>Login</h2>
        <form action="" method="post" >
          <div>
            <label for="uuid" class="form-label">Username/Email:</label>
            <input type="text" name="uuid" id="uuid" class="form-control" required>
          </div>
          <div>
            <label for="password" class="form-label">Password:</label>
            <input type="password" name="password" class="form-control" id="password" required>
          </div>
          <div class="mt-4 d-flex justify-content-center">
            <input type="submit" name="login" class="btn btn-primary mx-2" value="Login">
            <input type="submit" name="registration" class="btn btn-secondary mx-2" value="Registration">
          </div>
        </form>
      </div>
    <?php } ?>
  </main>
</body>
</html>


