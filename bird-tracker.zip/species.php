<?php

require('lib/layout.inc');
require('lib/db.inc');
session_start();

if (!isset($_SESSION['auth'])) {
    header('Location: index.php');
}

global $conn;

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM species WHERE `id`=$id";
    $rs = $conn->query($query) or die("Error in species SELECT operation");
    if ($rs->num_rows != 1) {
        die("Error in query");
    } else {
        $row = $rs->fetch_assoc();
        $nome = $row['nome'];
        $page = <<< PAGE
            <h1>$nome</h1>
        PAGE;
    }
} else {
    $table_data = "";
    $query = "SELECT * FROM species WHERE true";
    if (isset($_POST['filter'])) {
        $sel_order = isset($_POST['order']) ? $_POST['order'] : '';
        $sel_family = isset($_POST['family']) ? $_POST['family'] : '';
        $sel_status = isset($_POST['status']) ? $_POST['status'] : '';
        if (!empty($sel_order)) {
            $query .= " AND `order`='" . $_POST['order']. "'";
        }
        if (!empty($sel_family)) {
            $query .= " AND `family`='" . $_POST['family'] . "'";
        }
        if (!empty($sel_status)) {
            $query .= " AND `status`='" . $_POST['status'] . "'";
        }
    }
    $rs = $conn->query($query) or die("Error in species SELECT operation");
    $orders = $conn->query("SELECT DISTINCT `order` FROM species ORDER BY `order`");
    $families = $conn->query("SELECT DISTINCT `family` FROM species ORDER BY `family`");
    $status = $conn->query("SELECT DISTINCT `status` FROM species ORDER BY `status`");

    $order_counts = []; // Array in cui salvo il numero di righe per ogni ordine
    $order_families = []; // Array in cui salvo il numero di righe per ogni famiglia di ogni ordine
    while ($row = $rs->fetch_assoc()) {
        $order = $row['order'];
        $family = $row['family'];

        if (!isset($order_counts[$order])) {
            $order_counts[$order] = 0;
            $order_families[$order] = [];
        }
        $order_counts[$order]++;

        if (!isset($order_families[$order][$family])) {
            $order_families[$order][$family] = [];
        }
        $order_families[$order][$family][] = $row;
    }

    foreach ($order_counts as $order => $count) {
        $first_order_row = true; // Variabile flag per tenere traccia della prima riga di ogni ordine
        foreach ($order_families[$order] as $family => $rows) {
            $family_count = count($rows);
            $first_family_row = true; // Variabile flag per tenere traccia della prima riga di ogni ordine
            foreach ($rows as $row) {
                if ($first_order_row) {
                    $table_data .= '<tr>';
                    $table_data .= '<td style="vertical-align:middle" rowspan="' . $count . '">' . $order . '</td>'; // Imposta rowspan per ogni ordine
                    $first_order_row = false;
                }
                if ($first_family_row) {
                    $table_data .= '<td style="vertical-align:middle" rowspan="' . $family_count . '">' . $family . '</td>'; // Imposta rowspan per ogni famiglia
                    $first_family_row = false;
                }
                $table_data .= '<td onclick="window.location.href=\'species.php?id='.$row['id'].'\'">' . $row['sciname'] . '</td>';
                $table_data .= '<td onclick="window.location.href=\'species.php?id='.$row['id'].'\'">' . $row['nome'] . '</td>';
                $table_data .= '<td>' . $row['status'] . '</td>';
                $table_data .= '</tr>';
            }
        }
    }

    $order_options = "";
    while ($row = $orders->fetch_assoc()) {
        $order_options .= "<option value='" . htmlspecialchars($row['order']) . "'>" . htmlspecialchars($row['order']) . "</option>";
    }
    $family_options = "";
    while ($row = $families->fetch_assoc()) {
        $family_options .= "<option value='" . htmlspecialchars($row['family']) . "'>" . htmlspecialchars($row['family']) . "</option>";
    }
    $status_options = "";
    while ($row = $status->fetch_assoc()) {
        $status_options .= "<option value='" . htmlspecialchars($row['status']) . "'>" . htmlspecialchars($row['status']) . "</option>";
    }

    $page = <<< PAGE
    <div class="container">
        <h1>Lista delle specie</h1>
        <form action="" method="post" class="my-5">
            <div class="row">
                <div class="col">
                    <select class="form-select" id="order" name="order">
                        <option value="">Seleziona Ordine</option>
                        $order_options;
                    </select>
                </div>
                <div class="col">
                    <select class="form-select" id="family" name="family">
                        <option value="">Seleziona Famiglia</option>
                        $family_options;
                    </select>
                </div>
                <div class="col">
                    <select class="form-select" id="status" name="status">
                        <option value="">Seleziona Stato di conservazione</option>
                        $status_options;
                    </select>
                </div>
                <div class="col flex-grow-0">
                    <input class="btn btn-secondary" type="submit" name="filter" value="Filtra">
                </div>
            </div>
        </form>
        <table class="table">
          <thead>
            <th>Ordine</th>
            <th>Famiglia</th>
            <th>Nome Scientifico</th>
            <th>Nome</th>
            <th>Stato di conservazione</th>
          </thead>
          $table_data
        </table>
    </div>
    PAGE;
}
?>

<!DOCTYPE html>
<html lang="it">
<?= set_head('Bird Tracker | Specie'); ?>
<body>
  <?php render_navbar(); ?>
  <main>
    <?= $page ?> 
  </main>
</body>
</html>
