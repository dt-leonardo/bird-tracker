<?php

require('lib/layout.inc');
session_start();

?>

<!DOCTYPE html>
<html lang="it">
<?= set_head('Bird Tracker | Contatti'); ?>
<body>
    <?= render_navbar() ?>
    <div class="container">
        <h2 class="mt-4">Contatti</h2>
        <p><b>Leonardo Dalla Torre:</b></p>
        <ul>
            <li>Email: ldallatorre@hotmail.com</li>
            <li>Telegram: @leonardo_dallatorre</li>
        </ul>
    </div>
</body>
</html>
