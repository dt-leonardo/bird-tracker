# bird-tracker
<?php render_navbar() ?>
  <main>
    <?php
    if (!isset($_SESSION['auth'])) {
        echo render_landing_no_auth();
    } else {
        ?>
    <h1>HI!</h1>
    <?php } ?>
  </main>